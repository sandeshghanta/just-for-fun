import requests, re
from bs4 import BeautifulSoup

file = open("C:\Users\sandesh\Desktop\work\justforfun\websitelist.txt","w+")
url = 'http://www.google.com/search'
query = raw_input("Enter your query")
payload = { 'q' : query }

my_headers = { 'User-agent' : 'Mozilla/11.0' }
r = requests.get( url, params = payload, headers = my_headers )

soup = BeautifulSoup( r.text, 'html.parser' )
h3tags = soup.find_all( 'h3', class_='r' )

for h3 in h3tags:
  if h3:
    name = h3.a['href'].split('q=')[1].split('&')[0]
    print name
    file.write(name+"\n")
file.close()

